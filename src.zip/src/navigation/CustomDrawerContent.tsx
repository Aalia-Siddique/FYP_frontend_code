// import React from 'react';
// import { DrawerContentComponentProps } from '@react-navigation/drawer';
// import { View } from 'react-native';
// import Headers from '../components/Header'; // Import Headers component

// // Explicitly define the types for props to include children
// const CustomDrawerContent = (props: DrawerContentComponentProps & { children?: React.ReactNode }) => {
//   return (
//     <View style={{ flex: 1 }}>
//       {/* Header at the top */}
//       <Headers />
//       {/* Drawer Screens */}
//       <View style={{ flex: 1 }}>
//         {/* Default Drawer Content */}
//         {props.children}
//       </View>
//     </View>
//   );
// };

// export default CustomDrawerContent;
