import React, { useState, useEffect } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, ScrollView, TextInput, Button } from 'react-native';

const Me = () => {
  interface ProfileData {
    firstName: string;
    lastName: string;
    phoneNumber: string;
    address: string;
    cnic: string;
    password:string;

  }

  const [data, setData] = useState<ProfileData>({
    firstName: '',
    lastName: '',
    phoneNumber: '',
    address: '',
    cnic: '',
    password:'',
  });

  const [editingSection, setEditingSection] = useState<string | null>(null);
  const [tempData, setTempData] = useState<string>('');


  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://192.168.0.101:5269/api/User/GetUsersById');
        const result = await response.json();
  
        console.log('API Response:', result);
  
        setData({
          firstName: result.firstName || '',
          lastName: result.lastName || '',
          phoneNumber: result.phoneNumber || '',
          address: result.address || '',
          cnic: result.cnic || '',
          password:result.password
        });
  
        console.log('State Updated to:', {
          firstName: result.firstName,
          lastName: result.lastName,
          phoneNumber: result.phoneNumber,
          address: result.address,
          cnic: result.cnic,
        });
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
  
    fetchData();
  }, []);
  
  

  const handleEdit = (section: keyof ProfileData) => {
    setEditingSection(section);
    setTempData(data[section]);
  };

  const handleSave = () => {
    if (editingSection) {
      setData({ ...data, [editingSection]: tempData });
      setEditingSection(null);
    }
  };

  const renderEditableField = (section: keyof ProfileData) => (
    <View>
      <TextInput
        style={styles.input}
        value={tempData}
        onChangeText={setTempData}
        placeholder={`Edit ${section}`}
      />
      <Button title="Save" onPress={handleSave} color="#006400" />
    </View>
  );

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
     {/* Connections Section */}



      {/* Profile Header */}
      <View style={styles.profileHeader}>
        <View style={styles.profileImageContainer}>
          <Image source={require('../../assests/icons/user.png')} style={styles.profileImage} />
        </View>
        <Text style={styles.profileName}>{`${data.firstName} ${data.lastName}`}</Text>
        <Text style={styles.profileLocation}>{data.address}</Text>
      </View>
      <View style={[styles.detailContainer, styles.borderGreen]}>
        <View style={styles.detailHeader}>
          <Image source={require('../../assests/icons/connections.png')} style={[styles.icon, styles.iconGreen]} />
          <Text style={styles.detailText}>Connections</Text>
        </View>
        <View style={styles.greenDivider} />
        <View>
      
      <ScrollView horizontal={true} style={styles.horicontainer}>
      <View style={styles.item}>
        <Image
          source={require('../../Images/Homeimages/m1.jpeg')}
          resizeMode="cover"
          style={styles.horiimage}
        />
        <Text style={styles.horitext}>Umar Shahid</Text>
      </View>
      <View style={styles.item}>
        <Image
          source={require('../../Images/Homeimages/m2.jpeg')}
          resizeMode="cover"
          style={styles.horiimage}
        />
        <Text style={styles.horitext}>Khalida Farooq</Text>
      </View>
      <View style={styles.item}>
        <Image
          source={require('../../Images/Homeimages/m7.jpeg')}
          resizeMode="cover"
          style={styles.horiimage}
        />
        <Text style={styles.horitext}>Aiman Mughal</Text>
      </View>
      <View style={styles.item}>
        <Image
          source={require('../../Images/Homeimages/m9.jpeg')}
          resizeMode="cover"
          style={styles.horiimage}
        />
        <Text style={styles.horitext}>Fatima Murtaza</Text>
      </View>
      <View style={styles.item}>
        <Image
          source={require('../../Images/Homeimages/m4.jpeg')}
          resizeMode="cover"
          style={styles.horiimage}
        />
        <Text style={styles.horitext}>Zumar Mohib</Text>
      </View>
      <View style={styles.item}>
        <Image
          source={require('../../Images/Homeimages/m6.jpeg')}
          resizeMode="cover"
          style={styles.horiimage}
        />
        <Text style={styles.horitext}>Gareeda Faris</Text>
      </View>
      <View style={styles.item}>
        <Image
          source={require('../../Images/Homeimages/m3.jpeg')}
          resizeMode="cover"
          style={styles.horiimage}
        />
        <Text style={styles.horitext}>Naemm ul Haq</Text>
      </View>
    </ScrollView>
    </View>
      </View>

      {/* Contact Info */}
      <View style={[styles.detailContainer, styles.borderGreen]}>
        <View style={styles.detailHeader}>
          <Image source={require('../../assests/icons/contact.png')} style={[styles.icon, styles.iconGreen]} />
          <Text style={styles.detailText}>Contact Info</Text>
          <TouchableOpacity onPress={() => handleEdit('phoneNumber')}>
            <Image source={require('../../assests/icons/edit.png')} style={[styles.icon, styles.iconGreen]} />
          </TouchableOpacity>
        </View>
        
        {editingSection === 'phoneNumber' ? renderEditableField('phoneNumber') : <Text style={styles.detailValue}>{data.phoneNumber}</Text>}
        <View style={styles.greenDivider} />
      </View>
 {/* About Me */}
 <View style={[styles.detailContainer, styles.borderGreen]}>
        <View style={styles.detailHeader}>
          <Image source={require('../../assests/icons/user.png')} style={[styles.icon, styles.iconGreen]} />
          <Text style={styles.detailText}>Home Address</Text>
          <TouchableOpacity onPress={() => handleEdit('address')}>
            <Image source={require('../../assests/icons/edit.png')} style={[styles.icon, styles.iconGreen]} />
          </TouchableOpacity>
        </View>
        <View style={styles.greenDivider} />
        {editingSection === 'address' ? renderEditableField('address') : <Text style={styles.detailValue}>{data.address}</Text>}
       
      </View>
      {/* CNIC */}
      <View style={[styles.detailContainer, styles.borderGreen]}>
        <View style={styles.detailHeader}>
          <Image source={require('../../assests/icons/user.png')} style={[styles.icon, styles.iconGreen]} />
          <Text style={styles.detailText}>CNIC</Text>
        <TouchableOpacity onPress={() => handleEdit('address')}>
            <Image source={require('../../assests/icons/edit.png')} style={[styles.icon, styles.iconGreen]} />
          </TouchableOpacity>
        </View>
        <View style={styles.greenDivider} />
        <Text style={styles.detailValue}>{data.cnic}</Text>
        
      </View>
        {/* Experience
        <View style={[styles.detailContainer, styles.borderGreen]}>
        <View style={styles.detailHeader}>
          <Image source={require('../../assests/icons/suitcase.png')} style={[styles.icon, styles.iconGreen]} />
          <Text style={styles.detailText}>Experience</Text>
          <TouchableOpacity onPress={() => handleEdit('experience')}>
            <Image source={require('../../assests/icons/edit.png')} style={[styles.icon, styles.iconGreen]} />
          </TouchableOpacity>
        </View>
        <View style={styles.greenDivider} />
        {editingSection === 'experience' ? renderEditableField('experience') : <Text style={styles.detailValue}>{data.experience}</Text>}
      </View>

      {Education }
      <View style={[styles.detailContainer, styles.borderGreen]}>
        <View style={styles.detailHeader}>
          <Image source={require('../../assests/icons/education.png')} style={[styles.icon, styles.iconGreen]} />
          <Text style={styles.detailText}>Education</Text>
          <TouchableOpacity onPress={() => handleEdit('education')}>
            <Image source={require('../../assests/icons/edit.png')} style={[styles.icon, styles.iconGreen]} />
          </TouchableOpacity>
        </View>
        <View style={styles.greenDivider} />
        {editingSection === 'education' ? renderEditableField('education') : <Text style={styles.detailValue}>{data.education}</Text>}
      </View> */}
    </ScrollView>
  );
};

export default Me;

const styles = StyleSheet.create({
  horicontainer: {
    padding: 5,
  },
  item: {
    alignItems: 'center',
    marginRight: 2,
  },
  horiimage: {
    width: 70,
    height: 70,
    borderRadius: 45,
    borderWidth: 2,
    borderColor: '#4CAF50',
  },
  horitext: {
    marginTop: 5,
    fontSize: 10,
    color: '#000',
  },
  container: {
    flex: 1,
    backgroundColor: '#f9f9f9',
  },
  contentContainer: {
    padding: 20,
  },
  profileHeader: {
    alignItems: 'center',
    marginBottom: 20,
  },
  profileImageContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    overflow: 'hidden',
    marginBottom: 10,
    borderColor: '#4CAF50',
  },
  profileImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  profileName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
  },
  profileLocation: {
    fontSize: 16,
    color: '#777',
  },
  detailContainer: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  borderGreen: {
    borderWidth: 2,
    borderColor: '#4CAF50',
  },
  detailHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  detailText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
    marginLeft: 10,
  },
  connectionsText: {
    fontSize: 16,
    color: '#4CAF50',
  },
  detailValue: {
    fontSize: 16,
    color: '#555',
  },
  icon: {
    width: 24,
    height: 24,
    resizeMode: 'contain',
  },
  iconGreen: {
    tintColor: '#4CAF50',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
    fontSize: 16,
  },
  greenDivider: {
    height: 1,
    backgroundColor: '#4CAF50',
    marginVertical: 10,
  },
}); 
